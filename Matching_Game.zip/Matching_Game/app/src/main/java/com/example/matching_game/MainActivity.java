package com.example.matching_game;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class  MainActivity extends AppCompatActivity {
    MediaPlayer tune;
    TextView scoreboard, timeboard;
    ImageView img1, img2, img3, img4, img5, img6, img7, img8;
    Integer[] cards = {11,12,13,14,21,22,23,24};
    int image11, image12, image13, image14, image21, image22, image23, image24;
    int first, second;
    int firstClicked, secondClicked;
    int cardNumber = 1;
    int turnNumber = 1;
    int score = 0;

   /*int secondsLeft = 60;

    CountDownTimer timer = new CountDownTimer("60000","1000") {
        @Override
        public void onTick(long l) {
            secondsLeft--;
            timeboard.setText(secondsLeft + "seconds");


        }

        @Override
        public void onFinish() {
            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            img7.setEnabled(false);
            img8.setEnabled(false);
            timeboard.setText("TIME OVER!! ");

        }
    };*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        timeboard = (TextView) findViewById(R.id.timeboard);
        long timer = TimeUnit.MINUTES.toMillis(1);

        new CountDownTimer(timer, 1000) {
            @Override
            public void onTick(long l) {
                String time = String.format(Locale.CANADA,"%02d : %02d"
                        ,TimeUnit.MILLISECONDS.toMinutes(l)
                        ,TimeUnit.MILLISECONDS.toSeconds(l) -
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(l)));

                timeboard.setText(time);

            }

            @Override
            public void onFinish() {
                timeboard.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "TIME OVER", Toast.LENGTH_LONG).show();
                {

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
                    alertDialogBuilder
                            .setMessage(" TIME IS UP!! \n Score:" + score)
                            //.setCancelable(false)
                            .setPositiveButton("NEW GAME", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                    startActivity(intent);
                                    finish();

                                }
                            })
                            .setNegativeButton("EXIT GAME", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    finish();
                                }
                            });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();


                }

            }
        }.start();




        scoreboard = (TextView) findViewById(R.id.scoreboard);
        img1 = (ImageView) findViewById(R.id.img1);
        img2 = (ImageView) findViewById(R.id.img2);
        img3 = (ImageView) findViewById(R.id.img3);
        img4 = (ImageView) findViewById(R.id.img4);
        img5 = (ImageView) findViewById(R.id.img5);
        img6 = (ImageView) findViewById(R.id.img6);
        img7 = (ImageView) findViewById(R.id.img7);
        img8 = (ImageView) findViewById(R.id.img8);

        img1.setTag("0");
        img2.setTag("1");
        img3.setTag("2");
        img4.setTag("3");
        img5.setTag("4");
        img6.setTag("5");
        img7.setTag("6");
        img8.setTag("7");

        frontOfCards();


        Collections.shuffle(Arrays.asList(cards));

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img1, card);

            }
        });

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img2, card);

            }
        });

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img3, card);

            }
        });

        img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img4, card);

            }
        });

        img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img5, card);

            }
        });

        img6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img6, card);

            }
        });

        img7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img7, card);

            }
        });

        img8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int card = Integer.parseInt((String) view.getTag());
                doShuffle(img8, card);

            }
        });


    }
    private void doShuffle(ImageView img, int cardType ){
        if (cards[cardType] == 11){
            img.setImageResource(image11);
        }
        else if (cards[cardType] == 12){
            img.setImageResource(image12);
        }
        else if (cards[cardType] == 13){
            img.setImageResource(image13);
        }
        else if (cards[cardType] == 14){
            img.setImageResource(image14);
        }
        else if (cards[cardType] == 21){
            img.setImageResource(image21);
        }
        else if (cards[cardType] == 22){
            img.setImageResource(image22);
        }
        else if (cards[cardType] == 23){
            img.setImageResource(image23);
        }
        else if (cards[cardType] == 24){
            img.setImageResource(image24);
        }

        if(cardNumber == 1){
            first = cards[cardType];
            if(first > 20){
                first = first - 10;

            }
            cardNumber = 2;
            firstClicked = cardType;

            img.setEnabled(false);
        }
        else if(cardNumber == 2){
            second = cards[cardType];
            if(second > 20){
                second = second - 10;
            }
            cardNumber = 1;
            secondClicked = cardType;

            img1.setEnabled(false);
            img2.setEnabled(false);
            img3.setEnabled(false);
            img4.setEnabled(false);
            img5.setEnabled(false);
            img6.setEnabled(false);
            img7.setEnabled(false);
            img8.setEnabled(false);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    calculate();
                }
            },1000);
        }
    }

    private void calculate(){
        if(first == second){
            tune = MediaPlayer.create(MainActivity.this,R.raw.tune);
            tune.start();
            //timer.start();
            if (firstClicked == 0){
                img1.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 1){
                img2.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 2){
                img3.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 3){
                img4.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 4){
                img5.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 5){
                img6.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 6){
                img7.setVisibility(View.INVISIBLE);
            }
            else if (firstClicked == 7){
                img8.setVisibility(View.INVISIBLE);
            }



            if (secondClicked == 0){
                img1.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 1){
                img2.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 2){
                img3.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 3){
                img4.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 4){
                img5.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 5){
                img6.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 6){
                img7.setVisibility(View.INVISIBLE);
            }
            else if (secondClicked == 7){
                img8.setVisibility(View.INVISIBLE);
            }



            if(turnNumber == 1){
                score++;
                scoreboard.setText("Score: " + score);
            }
            else if(turnNumber == 2){
                score++;
                scoreboard.setText("Score: " + score);
            }

        }
        else{
            img1.setImageResource(R.drawable.hidden);
            img2.setImageResource(R.drawable.hidden);
            img3.setImageResource(R.drawable.hidden);
            img4.setImageResource(R.drawable.hidden);
            img5.setImageResource(R.drawable.hidden);
            img6.setImageResource(R.drawable.hidden);
            img7.setImageResource(R.drawable.hidden);
            img8.setImageResource(R.drawable.hidden);

            if (turnNumber == 1){
                turnNumber = 2;
                scoreboard.setTextColor(Color.GRAY);
            }
            else if (turnNumber == 2){
                turnNumber = 1;
                scoreboard.setTextColor(Color.GREEN);
            }

        }
        img1.setEnabled(true);
        img2.setEnabled(true);
        img3.setEnabled(true);
        img4.setEnabled(true);
        img5.setEnabled(true);
        img6.setEnabled(true);
        img7.setEnabled(true);
        img8.setEnabled(true);

        checkGameOver();
    }
    private void checkGameOver(){
        if(img1.getVisibility() == View.INVISIBLE &&
                img2.getVisibility() == View.INVISIBLE &&
                img3.getVisibility() == View.INVISIBLE &&
                img4.getVisibility() == View.INVISIBLE &&
                img5.getVisibility() == View.INVISIBLE &&
                img6.getVisibility() == View.INVISIBLE &&
                img7.getVisibility() == View.INVISIBLE &&
                img8.getVisibility() == View.INVISIBLE) {

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder
                    .setMessage("$$ GAME OVER $$ \n Score:" + score)
                    .setCancelable(false)
                    .setPositiveButton("NEW GAME", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                            finish();

                        }
                    })
                    .setNegativeButton("EXIT GAME", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();


        }
    }

    private void frontOfCards() {
        image11 = R.drawable.image1;
        image12 = R.drawable.image2;
        image13 = R.drawable.image3;
        image14 = R.drawable.image4;
        image21 = R.drawable.image5;
        image22 = R.drawable.image6;
        image23 = R.drawable.image7;
        image24 = R.drawable.image8;
    }
}

/* Created by: Mihirkumar Dilipbhai Patel
   Student ID: T00681063
 */

