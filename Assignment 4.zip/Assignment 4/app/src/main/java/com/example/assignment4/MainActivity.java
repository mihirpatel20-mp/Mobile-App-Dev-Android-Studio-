package com.example.assignment4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import java.util.Collection;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;




    int flip[]={1,1,2,2,3,3,4,4};
    Random rand;
    int i,x,y, index_temp=0, click_counter=0, pair_check=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        ArrayList<Integer> list = new ArrayList<>();
        Random rand = new Random();
        list.add(R.drawable.img1);
        list.add(R.drawable.img5);
        list.add(R.drawable.img2);
        list.add(R.drawable.img6);
        list.add(R.drawable.img3);
        list.add(R.drawable.img7);
        list.add(R.drawable.img4);
        list.add(R.drawable.img8);
         for(i=0; i< 100, i++){
             x = rand.nextInt(7);
            y = rand.nextInt(7);
            Collections.swap(list, x, y);
        }
        Log.d("tag_1","Updated_List"+ list.toString());
        binding.image1.setBackground(getDrawable(R.drawable.background));
        binding.image2.setBackground(getDrawable(R.drawable.background));
        binding.image3.setBackground(getDrawable(R.drawable.background));
        binding.image4.setBackground(getDrawable(R.drawable.background));
        binding.image5.setBackground(getDrawable(R.drawable.background));
        binding.image6.setBackground(getDrawable(R.drawable.background));
        binding.image7.setBackground(getDrawable(R.drawable.background));
        binding.image8.setBackground(getDrawable(R.drawable.background));

        binding.image1.setOnClickListener(imageButtonListener);
        binding.image2.setOnClickListener(imageButtonListener);
        binding.image3.setOnClickListener(imageButtonListener);
        binding.image4.setOnClickListener(imageButtonListener);
        binding.image5.setOnClickListener(imageButtonListener);
        binding.image6.setOnClickListener(imageButtonListener);
        binding.image7.setOnClickListener(imageButtonListener);
        binding.image8.setOnClickListener(imageButtonListener);




        /* binding.image1.setBackground(getDrawable(list.get(1)));
         binding.image2.setBackground(getDrawable(list.get(1)));
         binding.image3.setBackground(getDrawable(list.get(1)));
         binding.image4.setBackground(getDrawable(list.get(1)));
         binding.image5.setBackground(getDrawable(list.get(1)));
         binding.image6.setBackground(getDrawable(list.get(1)));
         binding.image7.setBackground(getDrawable(list.get(1)));
         binding.image8.setBackground(getDrawable(list.get(1)));*/

        View.OnClickListener imageButtonListener = new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int buttonId = view.getId();

                if(buttonId == R.id.image1){
                    Log.d("tag_1","buttonId " +buttonId);
                }

            }
        }


    }
}